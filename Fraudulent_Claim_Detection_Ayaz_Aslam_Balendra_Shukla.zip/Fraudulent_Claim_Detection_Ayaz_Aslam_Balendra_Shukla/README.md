Fraud Detection - Insurance

Fraud is causing billions of dollars in losses for the insurance industry.
This project aims to develop a machine learning algorithm to detect fraudulent transactions effectively.

We use historical transaction data, including both normal and fraudulent claims, to extract behavioral features using machine learning techniques. These features are then used to predict whether a transaction is fraudulent.
A comparative study was also conducted to evaluate different classifiers and select the best model for this task.

Objective

The objective of this project is to build a model that can accurately predict whether an insurance claim is fraudulent or not.

Plan

The dataset used consists of automobile insurance claims.
The goal is to create a predictive model that classifies claims as either fraudulent (YES) or not fraudulent (NO) — making this a binary classification problem.

In this project, we primarily use a Random Forest classification model to detect fraudulent transactions in Python.
Other classification algorithms were also evaluated to determine the most effective model.

⸻
